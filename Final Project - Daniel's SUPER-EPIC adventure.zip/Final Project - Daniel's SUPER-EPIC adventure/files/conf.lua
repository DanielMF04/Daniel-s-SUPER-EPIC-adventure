function love.conf(t)
    t.title = "Daniel's SUPER-EPIC adventure"
    t.window.icon = "assets/textures/gui/avatar.png"
    t.version = "11.3"
    t.window.msaa = 0
    t.window.vsync = 0
    t.window.width = 1280
    t.window.heigth = 720
end