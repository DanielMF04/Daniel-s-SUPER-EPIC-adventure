love.graphics.setDefaultFilter("nearest", "nearest")
local Player = require("player")
local Coin = require("coin")
local GUI = require("gui")
local Spike = require("spike")
local Crate = require("crate")
local Camera = require("camera")
local Blue_slime = require("Blue_slime")
local Map = require("map")
local Sound = require("sound")
local Menu = require("scenes/menu")
local MagicHeart = require("magicHeart")
local Heart = require("heart")
local Death = require("scenes/death")
local Door = require("door")
local Transition = require("scenes/transition")
local OptionsMenu = require("scenes/options_menu")
local Purple_slime = require("purple_slime")

function love.load()
    SCENARIO = "menu"
    Sound:load()
    
    Coin:loadAssets() 
    Blue_slime.loadAssets()
    Purple_slime.loadAssets()
    Spike:loadAssets()
    Map:load()
    Player:load()
    GUI:load()
    Menu:load()
    OptionsMenu:load()
    Death:load()
    Transition:load()
    Camera:load()
end

function love.update(dt)
    Sound:update(dt)
    OptionsMenu:update(dt)
    
    if SCENARIO == "main" then
        World:update(dt)
        Player:update(dt)
        Coin.updateAll(dt)
        MagicHeart.updateAll(dt)
        Heart.updateAll(dt)
        Spike.updateAll(dt)
        Crate.updateAll(dt)
        Blue_slime.updateAll(dt)
        Purple_slime.updateAll(dt)
        GUI:update(dt)
        Camera:update(dt)
        Map:update(dt)
        Menu.inMenu = true
    end
end

function love.draw()

    if SCENARIO == "main" or SCENARIO == "pause" then
        Map:draw()
        Map.level:draw(-Camera.x, -Camera.y, Camera.scale, Camera.scale)

        Camera:apply()
        Player:draw()
        Coin.drawAll()
        MagicHeart.drawAll()
        Heart.drawAll()
        Spike.drawAll()
        Crate.drawAll()
        Blue_slime.drawAll(dt)
        Purple_slime.drawAll(dt)
        Door.drawAll()
        Camera:clear()

        GUI:draw()
    end

    if SCENARIO == "menu" then
        love.graphics.draw(Map.dayBackground)
        Menu:draw()
    end

    if SCENARIO == "optionsMenu" then
        love.graphics.draw(Map.dayBackground)
        OptionsMenu:draw()
    end

    if SCENARIO == "death" then
        Death:draw()
    end

    if SCENARIO == "transition" then
        Transition:draw()
    end
end

function love.keypressed(key)

    if love.keyboard.isDown("escape") then
        Menu:mainMenu(key)
        Menu.inMenu = not Menu.inMenu
    end

    if SCENARIO == "main" then
        Player:jump(key)
        Player:doubleJump(key)

        if love.keyboard.isDown("e") and Player.grounded == true then
            if Door.inDoor == true then
                Map:enterDoor(key)
                Map.inRoom = not Map.inRoom
            end
        end
    end

    if SCENARIO == "main" or SCENARIO == "pause" then
        if key == "p" then
            GUI:pause(key)
            GUI.paused = not GUI.paused
        end
    end

    if SCENARIO == "death" then
        Death:respawn(key)
    end

    if SCENARIO == "transition" then
        Transition:skip(key)
    end
end

function beginContact(a, b, collision)

    if Coin.beginContact(a, b, collision) then return end
    if MagicHeart.beginContact(a, b, collision) then return end
    if Spike.beginContact(a, b, collision) then return end

    if Player.health.current + 1 <= Player.health.max then
         if Heart.beginContact(a, b, collision) then return end
    end

    Player:beginContact(a, b, collision)
    Crate.beginContact(a, b, collision)
    Blue_slime.beginContact(a, b, collision)
    Purple_slime.beginContact(a, b, collision)
    Door.beginContact(a, b, collision)
end

function endContact(a, b, collision)
    Player:endContact(a, b, collision)
    Door.endContact(a, b, collision)
end
