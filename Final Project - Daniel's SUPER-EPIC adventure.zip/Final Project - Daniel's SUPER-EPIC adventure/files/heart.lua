local Player = require("player")
local Sound = require("sound")
local GUI = require("gui")

local Heart = {}
Heart.__index = Heart
local ActiveHearts = {}

function Heart.new(x,y)
    local instance = setmetatable({}, Heart)
    instance.x = x
    instance.y = y

    instance.img = love.graphics.newImage("assets/textures/entities/heart.png")
    instance.width = instance.img:getWidth()
    instance.height = instance.img:getHeight()

    instance.toBeRemoved = false

    instance.physics = {}
    instance.physics.body = love.physics.newBody(World, instance.x, instance.y, "static")
    instance.physics.shape = love.physics.newRectangleShape(instance.width, instance.height)
    instance.physics.fixture = love.physics.newFixture(instance.physics.body, instance.physics.shape)
    instance.physics.fixture:setSensor(true)

    table.insert(ActiveHearts, instance)
end

function Heart:float()
    self.y = self.y + math.sin(love.timer.getTime() * 4) * 0.05
end

function Heart.beginContact(a, b, collision)
    for i,instance in ipairs(ActiveHearts) do
        if a == instance.physics.fixture or b == instance.physics.fixture then
            if a == Player.physics.fixture or b == Player.physics.fixture then
                instance.toBeRemoved = true
                return true
            end
        end
    end
end

function Heart:remove()
    for i, instance in ipairs(ActiveHearts) do
        if instance == self then
            Player:tint(0, 1, 0)
            GUI:heartsTint(0, 1, 0)
            Player:updateCurrentHealth(1)
            Sound:play("heart", "sfx")
            self.physics.body:destroy()
            table.remove(ActiveHearts, i)
        end
    end
end

function Heart:checkRemoved()
    if self.toBeRemoved then
        self:remove()
    end
end

function Heart:removeAll()
    for i,v in ipairs(ActiveHearts) do
        v.physics.body:destroy()
    end

    ActiveHearts = {}
end

function Heart:update(dt)
    self:checkRemoved()
    self:float()
end

function Heart.updateAll(dt)
    for i,instance in ipairs(ActiveHearts) do
        instance:update(dt)
    end
end

function Heart:draw()
    love.graphics.setColor(0, 0, 0, 0.25)
        love.graphics.draw(self.img, self.x + 1.5, self.y + 1.5, 0, 1, 1, self.width / 2, self.height / 2)
    love.graphics.setColor(1, 1, 1, 1)
        love.graphics.draw(self.img, self.x, self.y, 0, 1, 1, self.width / 2, self.height / 2)
end

function Heart.drawAll()
    for i,instance in ipairs(ActiveHearts) do
        instance:draw()
    end
end

return Heart