local Player = require("player")
local GUI = require("gui")

local Door = {}
Door.__index = Door
local ActiveDoors = {}

function Door.new(x,y,w,h)
    instance = setmetatable({}, Door)
    instance.x = x
    instance.y = y
    instance.width = w
    instance.height = h
    
    instance.inDoor = false

    instance.physics = {}
    instance.physics.body = love.physics.newBody(World, instance.x, instance.y, "static")
    instance.physics.shape = love.physics.newRectangleShape(instance.width, instance.height)
    instance.physics.fixture = love.physics.newFixture(instance.physics.body, instance.physics.shape)
    instance.physics.fixture:setSensor(true)

    table.insert(ActiveDoors, instance)
end

function Door.beginContact(a, b, collision)
    for i,instance in ipairs(ActiveDoors) do
        if a == instance.physics.fixture or b == instance.physics.fixture then
            if a == Player.physics.fixture or b == Player.physics.fixture then
                Door.inDoor = true
            end
        end
    end
end

function Door.endContact(a, b, collision)
    for i,instance in ipairs(ActiveDoors) do
        if a == Player.physics.fixture or b == Player.physics.fixture then
            if a ~= instance.physics.fixture or b ~= instance.physics.fixture then
                Door.inDoor = false
            end
        end
    end
end

function Door:removeAll()
    for i,v in ipairs(ActiveDoors) do
        v.physics.body:destroy()
    end

    ActiveDoors = {}
end

function Door:draw()
    local textW = GUI.font:getWidth("\"E\" to enter.")
    local textH = GUI.font:getHeight("\"E\" to enter.")
    local Scale = 0.5

    if Door.inDoor == true and Player.grounded == true then
        love.graphics.setColor(0, 0, 0)
            love.graphics.print("\"E\" to enter.", GUI.font, (instance.x - textW / 4) + 1.5, (instance.y - instance.height / 2 - textH / 2) + 1.5, 0, Scale, Scale)
        love.graphics.setColor(1, 1, 1)
            love.graphics.print("\"E\" to enter.", GUI.font, instance.x - textW / 4, instance.y - instance.height / 2 - textH / 2, 0, Scale, Scale)
    end
end

function Door.drawAll()
    for i,instance in ipairs(ActiveDoors) do
        instance:draw()
    end
end

return Door