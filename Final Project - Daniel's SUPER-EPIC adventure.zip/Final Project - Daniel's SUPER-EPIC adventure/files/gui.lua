local Player = require("player")
local GUI = {}


function GUI:load()

    self.scoreColor = {
        red = 1,
        green = 1,
        blue = 1,
        speed = 3,
    }

    self.heartsColor = {
        red = 1,
        green = 1,
        blue = 1,
        speed = 3,
    }

    self.emptyHearts = {}
    self.emptyHearts.img = love.graphics.newImage("assets/textures/gui/heart_empty.png")
    self.emptyHearts.width = self.emptyHearts.img:getWidth()
    self.emptyHearts.height = self.emptyHearts.img:getHeight()
    self.emptyHearts.x = 80
    self.emptyHearts.y = 38
    self.emptyHearts.scale = 3
    self.emptyHearts.spacing = self.emptyHearts.width * self.emptyHearts.scale + 10

    self.hearts = {}
    self.hearts.img = love.graphics.newImage("assets/textures/gui/heart.png")
    self.hearts.width = self.hearts.img:getWidth()
    self.hearts.height = self.hearts.img:getHeight()
    self.hearts.x = 80
    self.hearts.y = 38
    self.hearts.scale = 3
    self.hearts.spacing = self.hearts.width * self.hearts.scale + 10

    self.avatar = {}
    self.avatar.img = love.graphics.newImage("assets/textures/gui/avatar.png")
    self.avatar.x = 28
    self.avatar.y = 30
    self.avatar.scale = 3

    self.clock = {}
    self.clock.img = love.graphics.newImage("assets/textures/gui/clock.png")
    self.clock.x = 1143
    self.clock.y = 40
    self.clock.scale = 3

    self.font = love.graphics.newFont("assets/textures/fonts/bit.ttf", 36)
    self.font2 = love.graphics.newFont("assets/textures/fonts/bit.ttf", 100)

    self.time = 181

    self.paused = true

    self.ww = love.graphics.getWidth()
    self.wh = love.graphics.getHeight()
end

function GUI:update(dt)
    self:unTint(dt)
    self:timer(dt)
end

function GUI:updateScore(amount)
    Player.score = Player.score + amount

    if amount > 0 then
        self:scoreTint(0, 1, 0)
    else
        self:scoreTint(1, 0, 0)
        self:heartsTint(1, 0, 0)
    end

    if Player.score - amount < 0 or Player.score < 0 then
        Player.score = 0
    end
end

function GUI:scoreTint(red, green, blue)
    if Player.health.current - 1 >= 0 then
        self.scoreColor.red = red
        self.scoreColor.green = green
        self.scoreColor.blue = blue
    end
end

function GUI:unTint(dt)
    self.scoreColor.red = math.min(self.scoreColor.red + self.scoreColor.speed * dt, 1)
    self.scoreColor.green = math.min(self.scoreColor.green + self.scoreColor.speed * dt, 1)
    self.scoreColor.blue = math.min(self.scoreColor.blue + self.scoreColor.speed * dt, 1)
    self.heartsColor.red = math.min(self.heartsColor.red + self.heartsColor.speed * dt, 1)
    self.heartsColor.green = math.min(self.heartsColor.green + self.heartsColor.speed * dt, 1)
    self.heartsColor.blue = math.min(self.heartsColor.blue + self.heartsColor.speed * dt, 1)
end

function GUI:heartsTint(red, green, blue)
    if Player.health.current - 1 >= 0 then
        self.heartsColor.red = red
        self.heartsColor.green = green
        self.heartsColor.blue = blue
    end
end

function GUI:pause(key)
    if self.paused == false then
        SCENARIO = "main"
    elseif self.paused == true then
        SCENARIO = "pause"
    end
end

function GUI:timer(dt)
    self.time = self.time - dt

    if math.floor(self.time) == -1 then
        Player:die()
    end

    if SCENARIO == "death" then
        self:resetTimer()
    end
end

function GUI:resetTimer()
    self.time = 181
end

function GUI:displayIcons()
    love.graphics.setColor(0, 0, 0, 0.25)
        love.graphics.draw(self.avatar.img, self.avatar.x + 3, self.avatar.y + 3, 0, self.avatar.scale, self.avatar.scale)
    love.graphics.setColor(1, 1, 1, 1)
        love.graphics.draw(self.avatar.img, self.avatar.x, self.avatar.y, 0, self.avatar.scale, self.avatar.scale)

        love.graphics.draw(self.clock.img, self.clock.x, self.clock.y, 0, self.clock.scale, self.clock.scale)
end

function GUI:displayLives()
    local livesX = self.hearts.x + self.hearts.spacing * (Player.health.max + 1) - 35

    love.graphics.setColor(0, 0, 0, 0.5)
        love.graphics.print("x "..Player.health.lives, self.font, livesX + 2, 37.5 + 2)
    love.graphics.setColor(0.92, 0.92, 0.92)
        love.graphics.print("x "..Player.health.lives, self.font, livesX, 37.5)
    love.graphics.setColor(1, 1, 1)
end

function GUI:displayHearts()
    for i = 1, Player.health.current do
        local x = self.hearts.x + self.hearts.spacing * i - 40
        love.graphics.setColor(0, 0, 0, 0.25)
            love.graphics.draw(self.hearts.img, x + 3, self.hearts.y + 1.25, 0, self.hearts.scale, self.hearts.scale)
        love.graphics.setColor(self.heartsColor.red, self.heartsColor.green, self.heartsColor.blue)
            love.graphics.draw(self.hearts.img, x, self.hearts.y, 0, self.hearts.scale, self.hearts.scale)
        love.graphics.setColor(1, 1, 1, 1)
    end
    for j = 1, Player.health.max do
        local m = self.hearts.x + self.hearts.spacing * j - 40
        love.graphics.setColor(0, 0, 0, 0.25)
            love.graphics.draw(self.emptyHearts.img, m + 3, self.emptyHearts.y, 0, self.emptyHearts.scale, self.emptyHearts.scale)
        love.graphics.setColor(self.heartsColor.red, self.heartsColor.green, self.heartsColor.blue)
            love.graphics.draw(self.emptyHearts.img, m, self.emptyHearts.y, 0, self.emptyHearts.scale, self.emptyHearts.scale)
        love.graphics.setColor(1, 1, 1, 1)
    end
end

function GUI:displayPause()
    if SCENARIO == "pause" then
        local background = love.graphics.newImage("assets/textures/backgrounds/dimmed_background.png")
        local textW = self.font2:getWidth("PAUSED")
        local textW2 = self.font:getWidth("Press \"p\" to resume.")
        
        love.graphics.draw(background)
        
        love.graphics.setColor(0, 0, 0, 1)
            love.graphics.print("PAUSED", self.font2, (self.ww / 2) + 2.5 - (textW / 2), 80 + 2.5)
            love.graphics.print("Press \"p\" to resume.", self.font, (self.ww / 2) + 1.5 - (textW2 / 2), 170 + 1.5)
        love.graphics.setColor(1, 1, 1)
            love.graphics.print("PAUSED", self.font2, self.ww / 2 - textW / 2, 80)
            love.graphics.print("Press \"p\" to resume.", self.font, (self.ww / 2) - (textW2 / 2), 170)
    end
end

function GUI:displayScore()
    local textW = self.font:getWidth("SCORE : "..Player.score)

    love.graphics.setColor(0, 0, 0, 1)
        love.graphics.print("SCORE : "..Player.score, self.font, (self.ww / 2) + 2 - (textW / 2), 35 + 2)
    love.graphics.setColor(self.scoreColor.red, self.scoreColor.green, self.scoreColor.blue)
        love.graphics.print("SCORE : "..Player.score, self.font, (self.ww / 2) - (textW / 2), 35)
    love.graphics.setColor(1, 1, 1)
end

function GUI:displayTimer()
    love.graphics.setColor(0, 0, 0)
        love.graphics.print(": "..math.floor(self.time), self.font, self.ww - 100 + 2, 35 + 1.5)
    love.graphics.setColor(1, 1, 1)
        love.graphics.print(": "..math.floor(self.time), self.font, self.ww - 100, 35)
end

function GUI:draw()
    self:displayPause()
    self:displayScore()
    self:displayTimer()
    self:displayHearts()
    self:displayIcons()
    self:displayLives()
end

return GUI

