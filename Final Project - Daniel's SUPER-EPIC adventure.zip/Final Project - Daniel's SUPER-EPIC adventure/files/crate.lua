local Player = require("player")
local GUI = require("gui")
local Sound = require("sound")

local Crate = {}
Crate.__index = Crate

local ActiveCrates = {}

function Crate.new(x,y)
    local instance = setmetatable({}, Crate)
    instance.x = x
    instance.y = y
    instance.r = 0

    instance.img = love.graphics.newImage("assets/textures/entities/crate.png")
    instance.width = instance.img:getWidth()
    instance.height = instance.img:getHeight()

    instance.physics = {}
    instance.physics.body = love.physics.newBody(World, instance.x, instance.y, "dynamic")
    instance.physics.shape = love.physics.newRectangleShape(instance.width, instance.height)
    instance.physics.fixture = love.physics.newFixture(instance.physics.body, instance.physics.shape)
    instance.physics.body:setMass(25)
    table.insert(ActiveCrates, instance)
end

function Crate.beginContact(a, b, collision)
    for i,instance in ipairs(ActiveCrates) do
        if a == instance.physics.fixture or b == instance.physics.fixture then
            if a == Player.physics.fixture or b == Player.physics.fixture then
                Sound:play("crate", "sfx")
                return true
            end
        end
    end
end

function Crate:syncPhysics()
    self.x, self.y = self.physics.body:getPosition()
    self.r = self.physics.body:getAngle()
end

function Crate:update(dt)
    self:syncPhysics()
end

function Crate.updateAll(dt)
    for i,instance in ipairs(ActiveCrates) do
        instance:update(dt)
    end
end

function Crate:removeAll()
    for i,v in ipairs(ActiveCrates) do
        v.physics.body:destroy()
    end

    ActiveCrates = {}
end

function Crate:draw()
    love.graphics.draw(self.img, self.x, self.y, self.r, self.scaleX, 1, self.width / 2, self.height / 2)
end

function Crate.drawAll()
    for i,instance in ipairs(ActiveCrates) do
        instance:draw()
    end
end

return Crate