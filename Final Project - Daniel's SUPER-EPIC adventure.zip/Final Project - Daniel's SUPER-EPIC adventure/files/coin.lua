local Player = require("player")
local Sound = require("sound")
local GUI = require("gui")

local Coin = {}
Coin.__index = Coin
local ActiveCoins = {}

function Coin.new(x,y)
    local instance = setmetatable({}, Coin)
    instance.x = x
    instance.y = y

    instance.toBeRemoved = false

    instance.physics = {}
    instance.physics.body = love.physics.newBody(World, instance.x, instance.y, "static")
    instance.physics.shape = love.physics.newRectangleShape(instance.width, instance.height)
    instance.physics.fixture = love.physics.newFixture(instance.physics.body, instance.physics.shape)
    instance.physics.fixture:setSensor(true)

    instance.animation = {timer = 0, rate = 0.1}
    instance.animation.coin = {total = 8, current = 1, img = Coin.spinAnim}
    instance.animation.draw = instance.animation.coin.img[1]

    table.insert(ActiveCoins, instance)
end

function Coin:loadAssets()
    self.spinAnim = {}

    for i = 1, 8 do
        self.spinAnim[i] = love.graphics.newImage("assets/textures/entities/coin/"..i..".png")
    end
    self.width = self.spinAnim[1]:getWidth()
    self.height = self.spinAnim[1]:getHeight()
end

function Coin:setNewFrame()
    local frame = self.animation.coin

    if frame.current < frame.total then
        frame.current = frame.current + 1
    else
        frame.current = 1
    end
    self.animation.draw = frame.img[frame.current]
end

function Coin:animate(dt)
    self.animation.timer = self.animation.timer + dt

    if self.animation.timer > self.animation.rate then
        self.animation.timer = 0
        self:setNewFrame()
    end
end

function Coin.beginContact(a, b, collision)
    for i,instance in ipairs(ActiveCoins) do
        if a == instance.physics.fixture or b == instance.physics.fixture then
            if a == Player.physics.fixture or b == Player.physics.fixture then
                instance.toBeRemoved = true
                return true
            end
        end
    end
end

function Coin:remove()
    for i, instance in ipairs(ActiveCoins) do
        if instance == self then
            GUI:updateScore(100)
            Sound:play("coin", "sfx", 1)
            self.physics.body:destroy()
            table.remove(ActiveCoins, i)
        end
    end
end

function Coin:checkRemoved()
    if self.toBeRemoved then
        self:remove()
    end
end

function Coin:removeAll()
    for i,v in ipairs(ActiveCoins) do
        v.physics.body:destroy()
    end

    ActiveCoins = {}
end

function Coin:update(dt)
    self:checkRemoved()
    self:animate(dt)
end

function Coin.updateAll(dt)
    for i,instance in ipairs(ActiveCoins) do
        instance:update(dt)
    end
end

function Coin:draw()
    love.graphics.draw(self.animation.draw, self.x, self.y, 0, 1, 1, self.width / 2, self.height / 2)
end


function Coin.drawAll()
    for i,instance in ipairs(ActiveCoins) do
        instance:draw()
    end
end

return Coin