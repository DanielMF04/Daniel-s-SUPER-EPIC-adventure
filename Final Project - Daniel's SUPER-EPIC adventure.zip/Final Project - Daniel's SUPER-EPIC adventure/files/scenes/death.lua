local Menu = require("scenes/menu")
local GUI = require("gui")
local Player = require("player")
local Map = require("map")
local Sound = require("sound")

local Death = {}

function Death:load()
    self.font1 = love.graphics.newFont("assets/textures/fonts/bit.ttf", 100)
    self.font2 = love.graphics.newFont("assets/textures/fonts/bit.ttf", 60)
    self.font3 = love.graphics.newFont("assets/textures/fonts/bit.ttf", 45)
    self.font4 = love.graphics.newFont("assets/textures/fonts/bit.ttf", 180)

    self.ww = love.graphics.getWidth()
    self.wh = love.graphics.getHeight()
end

function Death:draw()
    local textW = self.font1:getWidth("Player died!")
    local textH = self.font1:getHeight("Player died!")
    local textW2 = self.font2:getWidth("Score : "..Player.score)
    local textH2 = self.font2:getHeight("Score : "..Player.score)
    local textW3 = self.font2:getWidth("Death counter : "..Player.deathCounter)
    local textH3 = self.font2:getHeight("Death counter : "..Player.deathCounter)
    local textW4 = self.font3:getWidth("\"ESC\" to main menu     \"SPACE\" to respawn.")
    local textH4 = self.font3:getHeight("\"ESC\" to main menu     \"SPACE\" to respawn.")
    local textW5 = self.font4:getWidth("GAME OVER")
    local textH5 = self.font4:getHeight("GAME OVER")
    local textW6 = self.font2:getWidth("Try again!")
    local textH6 = self.font2:getHeight("Try again!")
    local textW7 = self.font3:getWidth("\"SPACE\" to main menu.")
    local textH7 = self.font3:getHeight("\"SPACE\" to main menu.")

    if Player.health.lives >= 0 then
        love.graphics.print("Player died!", self.font1, (self.ww / 2) - (textW / 2), (self.wh * 0.15) - (textH / 2))
        love.graphics.print("Score : "..Player.score, self.font2, (self.ww / 2) - (textW2 / 2), (self.wh * 0.30) - (textH2 / 2))
        love.graphics.print("Death counter : "..Player.deathCounter, self.font2, (self.ww / 2) - (textW3 / 2), (self.wh * 0.775) - (textH3 / 2))
        love.graphics.print("\"ESC\" to main menu     \"SPACE\" to respawn.", self.font3, (self.ww / 2) - (textW4 / 2), (self.wh * 0.90) - (textH4 / 2))
    else
        Sound:stop("music")
        love.graphics.print("GAME OVER", self.font4, (self.ww / 2) - (textW5 / 2), (self.wh / 2) - (textH5 / 2))
        love.graphics.print("Score : "..Player.score, self.font2, (self.ww / 2) - (textW2 / 2), (self.wh * 0.30) - (textH2 / 2))
        love.graphics.print("\"SPACE\" to main menu.", self.font3, (self.ww / 2) - (textW7 / 2), (self.wh * 0.90) - (textH7 / 2))
    end
end

function Death:respawn(key)
    if love.keyboard.isDown("space") then
        if Player.health.lives >= 0 then
            SCENARIO = "main"
            Player.score = 0
        else
            Sound:play("wind", "music", 0.1, true)
            Menu.alreadyCreated = false
            Player.alive = false
            Player.score = 0
            Map:newGameMap()
            SCENARIO = "menu"
            Player.magicHeartGrabbed = false
        end
    end
end

return Death

