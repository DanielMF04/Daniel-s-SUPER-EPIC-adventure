local Sound = require("sound")

local OptionsMenu = {}

local squaredButtons = {}
local longButtons = {}

function OptionsMenu:load()
    self.sfxOffButton = love.graphics.newImage("assets/textures/menu_buttons/sound_fx_off_button.png")
    self.sfxOnButton = love.graphics.newImage("assets/textures/menu_buttons/sound_fx_on_button.png")
    self.backButton = love.graphics.newImage("assets/textures/menu_buttons/back_button.png")
    self.backButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/back_button_inverted.png")
    self.sfxOffButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/sound_fx_off_button_inverted.png")
    self.sfxOnButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/sound_fx_on_button_inverted.png")
    self.musicOffButton = love.graphics.newImage("assets/textures/menu_buttons/music_off_button.png")
    self.musicOnButton = love.graphics.newImage("assets/textures/menu_buttons/music_on_button.png")
    self.musicOffButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/music_off_button_inverted.png")
    self.musicOnButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/music_on_button_inverted.png")

    self.musicOn = true
    self.sfxOn = true
    self:buttonsList()
end

local function newButton(img, fn)
    return {img = img, fn = fn, now = false, last = false}
end

function OptionsMenu:buttonsList()
    table.insert(squaredButtons, newButton(
        self.sfxOnButton,
        function()
            Sound:play("button1", "sfx", 1)
            if self.sfxOn == true then
                self.sfxOn = false
            elseif self.sfxOn == false then
                self.sfxOn = true
            end
        end))

    table.insert(squaredButtons, newButton(
        self.musicOnButton,
        function()
            Sound:play("button1", "sfx", 1)
            if self.musicOn == true then
                self.musicOn = false
            elseif self.musicOn == false then
                self.musicOn = true
                Sound:play("wind", "music", 0.1, true)
            end
        end))

    table.insert(longButtons, newButton(
        self.backButton,
        function()
            Sound:play("button1", "sfx", 1)
            SCENARIO = "menu"
        end))
end

function OptionsMenu:update(dt)
    if self.musicOn == false then
        Sound:stop("music")
    end
    if self.sfxOn == false then
        Sound:stop("sfx")
    end
end

function OptionsMenu:draw()
    local ww = love.graphics.getWidth()
    local wh = love.graphics.getHeight()
    local buttonWidth = 260
    local buttonHeight = 152
    local margin = 32
    local totalWidth = (buttonWidth + margin) * #squaredButtons
    local xPosition = 0
    
    for i, button in ipairs(squaredButtons) do
        self.by = (wh / 2) - (buttonHeight)
        self.bx = (ww / 2) - totalWidth / 2 + xPosition + margin / 2
        self.mx, self.my = love.mouse.getPosition()
        local hoverH = self.my > self.by and self.my < self.by + buttonHeight
        local hover = hoverH and self.mx > self.bx and self.mx < self.bx + buttonWidth
        local hover1 = hoverH and self.mx > 364 and self.mx < 624
        local hover2 = hoverH and self.mx > 656 and self.mx < 916
        xPosition = xPosition + (buttonWidth + margin)
        button.past = button.last
        button.now = not love.mouse.isDown(1)
        button.last = not button.now

        if button.now and not button.last and hover and button.past then
            button.fn()
        end

        if self.sfxOn then
            if not hover1 then
                love.graphics.draw(self.sfxOnButton, 364, 148)
            else
                love.graphics.draw(self.sfxOnButtonInverted, 364, 148)
            end
        else
            if not hover1 then
                love.graphics.draw(self.sfxOffButton, 364, 148)
            else
                love.graphics.draw(self.sfxOffButtonInverted, 364, 148)
            end
        end

        if self.musicOn then
            if not hover2 then
                love.graphics.draw(self.musicOnButton, 656, 148)
            else
                love.graphics.draw(self.musicOnButtonInverted, 656, 148)
            end
        else
            if not hover2 then
                love.graphics.draw(self.musicOffButton, 656, 148)
            else
                love.graphics.draw(self.musicOffButtonInverted, 656, 148)
            end
        end
    end
    local buttonWidth2 = 427
    local buttonHeight2 = 68

    for i, button2 in ipairs(longButtons) do
        self.bx2 = 427
        self.by2 = 332
        local hoverW = self.mx > self.bx2 and self.mx < self.bx2 + buttonWidth2
        local hover = hoverW and self.my > self.by2 and self.my < self.by2 + buttonHeight2
        button2.past = button2.last
        button2.now = not love.mouse.isDown(1)
        button2.last = not button2.now

        if button2.now and not button2.last and hover and button2.past then
            button2.fn()
        end

        if not hover then
            love.graphics.draw(self.backButton, 427, 332)
        else
            love.graphics.draw(self.backButtonInverted, 427, 332)
        end
    end
end

return OptionsMenu