local GUI = require("gui")
local Player = require("player")
local Map = require("map")
local Sound = require("sound")

local Menu = {}
local buttons = {}

function Menu:load()
    self.startNewGameButton = love.graphics.newImage("assets/textures/menu_buttons/start_new_game_button.png")
    self.loadGameButton = love.graphics.newImage("assets/textures/menu_buttons/load_game_button.png")
    self.optionsButton = love.graphics.newImage("assets/textures/menu_buttons/options_button.png")
    self.exitGameButton = love.graphics.newImage("assets/textures/menu_buttons/exit_game_button.png")
    self.startNewGameButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/start_new_game_button_inverted.png")
    self.loadGameButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/load_game_button_inverted.png")
    self.optionsButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/options_button_inverted.png")
    self.exitGameButtonInverted = love.graphics.newImage("assets/textures/menu_buttons/exit_game_button_inverted.png")
    self.loadGameButtonRed = love.graphics.newImage("assets/textures/menu_buttons/load_game_button_red.png")

    self:buttonsList()

    self.alreadyCreated = false
    self.inMenu = false
    Sound:play("wind", "music", 0.1, true)
end

local function newButton(img, fn)
    return {img = img, fn = fn, now = false, last = false}
end

function Menu:buttonsList()
    table.insert(buttons, newButton(
        self.startNewGameButton,
        function()
            SCENARIO = "transition"
            Sound:stop("music")
            Sound:play("changingMap","sfx", 0.3)
            GUI:resetTimer()
            Player.score = 0
            Player:resetHealth()
            Map:newGameMap()
        end))

    table.insert(buttons, newButton(
        self.loadGameButton,
        function()
            if self.alreadyCreated == true then
                SCENARIO = "main"
                Sound:stop("music")
                Sound:play("song1", "music", 0.1, true)
            end
        end))

    table.insert(buttons, newButton(
        self.optionsButton,
        function()
            Sound:play("button1", "sfx", 1)
            SCENARIO = "optionsMenu"
        end))

    table.insert(buttons, newButton(
        self.exitGameButton,
        function()
            love.event.quit(0)
        end))
end

function Menu:draw()
    local ww = love.graphics.getWidth()
    local wh = love.graphics.getHeight()
    local buttonWidth = 427
    local buttonHeight = 68
    local margin = 16
    local totalHeight = (buttonHeight + margin) * #buttons
    local yPosition = 0

    for i, button in ipairs(buttons) do
        self.bx = (ww / 2) - (buttonWidth / 2)
        self.by = (wh / 2) - totalHeight / 2 + yPosition + margin / 2
        self.mx, self.my = love.mouse.getPosition()
        local hoverW = self.mx > self.bx and self.mx < self.bx + buttonWidth
        local hover = hoverW and self.my > self.by and self.my < self.by + buttonHeight
        yPosition = yPosition + (buttonHeight + margin)

        button.past = button.last
        button.now = not love.mouse.isDown(1)
        button.last = not button.now

        if button.now and not button.last and hover and button.past then
            button.fn()
        end
    end
    local hoverW = self.mx > self.bx and self.mx < self.bx + buttonWidth
    local hover1 = hoverW and self.my > 140 and self.my < 208
    local hover2 = hoverW and self.my > 224 and self.my < 292
    local hover3 = hoverW and self.my > 308 and self.my < 376
    local hover4 = hoverW and self.my > 392 and self.my < 460

    if not hover1 then
        love.graphics.draw(self.startNewGameButton, 426, 140, 0, 1, 1)
    else
        love.graphics.draw(self.startNewGameButtonInverted, 426, 140, 0, 1, 1)
    end

    if self.alreadyCreated then
        if not hover2 then
            love.graphics.draw(self.loadGameButton, 426, 224, 0, 1, 1)
        else
            love.graphics.draw(self.loadGameButtonInverted, 426, 224, 0, 1, 1)
        end
    else
        love.graphics.draw(self.loadGameButtonRed, 426, 224, 0, 1, 1)
    end

    if not hover3 then
        love.graphics.draw(self.optionsButton, 426, 308, 0, 1, 1)
    else
        love.graphics.draw(self.optionsButtonInverted, 426, 308, 0, 1, 1)
    end

    if not hover4 then
        love.graphics.draw(self.exitGameButton, 426, 392, 0, 1, 1)
    else
        love.graphics.draw(self.exitGameButtonInverted, 426, 392, 0, 1, 1)
    end
end

function Menu:mainMenu(key)
    if self.inMenu == false and self.alreadyCreated then
        SCENARIO = "main"
        Sound:stop("music")
        Sound:play("song1", "music", 0.1, true)
    elseif self.inMenu == true then
        SCENARIO = "menu"
        Sound:stop("music")
        Sound:play("wind", "music", 0.1, true)
    end
end

return Menu