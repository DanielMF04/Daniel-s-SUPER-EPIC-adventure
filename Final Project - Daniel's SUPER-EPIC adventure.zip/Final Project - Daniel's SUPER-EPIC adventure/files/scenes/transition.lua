local Menu = require("scenes/menu")
local GUI = require("gui")
local Player = require("player")
local Death = require("scenes/death")
local Map = require("map")
local Sound = require("sound")

local Transition = {}

function Transition:load()
    self.background1 = love.graphics.newImage("assets/textures/minimaps/1-1_minimap.png")
    self.background2 = love.graphics.newImage("assets/textures/minimaps/1-2_minimap.png")
    self.background3 = love.graphics.newImage("assets/textures/minimaps/1-3_minimap.png")
end

function Transition:draw()
    local ww = love.graphics.getWidth()
    local wh = love.graphics.getHeight()
    local textW = Death.font1:getWidth("Mysterious dungeon...")
    local textH = Death.font1:getHeight("Mysterious dungeon...")
    local textW2 = Death.font1:getWidth(Map.currentWorld.."-"..Map.currentLevel.number)
    local textH2 = Death.font1:getHeight(Map.currentWorld.."-"..Map.currentLevel.number)
    local textW3 = Death.font2:getWidth("Score : "..Player.score)
    local textH3 = Death.font2:getHeight("Score : "..Player.score)
    local textW4 = Death.font3:getWidth("\"SPACE\" to skip.")
    local textH4 = Death.font3:getHeight("\"SPACE\" to skip.")
    local textW5 = Death.font1:getWidth("The haunted mansion...")
    local textH5 = Death.font1:getHeight("The haunted mansion...")
    local textW6 = Death.font1:getWidth("You completed the game!!!")
    local textH6 = Death.font1:getHeight("You completed the game!!!")
    local textW7 = Death.font2:getWidth("Thank you for playing : )")
    local textH7 = Death.font2:getHeight("Thank you for playing : )")
    local textW8 = Death.font2:getWidth("Score : "..Player.score)
    local textH8 = Death.font2:getHeight("Score : "..Player.score)

    if Map.currentLevel.number == 2.1 then
        love.graphics.print("Mysterious dungeon...", Death.font1, (Death.ww / 2) - (textW / 2), (Death.wh / 2) - (textH / 2))
        love.graphics.print("\"SPACE\" to skip.", Death.font3, (Death.ww / 2) - (textW4 / 2), (Death.wh * 0.90) - (textH4 / 2))
    elseif Map.currentLevel.number == 3.1 then
        love.graphics.print("The haunted mansion...", Death.font1, (Death.ww / 2) - (textW5 / 2), (Death.wh / 2) - (textH5 / 2))
        love.graphics.print("\"SPACE\" to skip.", Death.font3, (Death.ww / 2) - (textW4 / 2), (Death.wh * 0.90) - (textH4 / 2))
    elseif Map.currentLevel.number == 4 then
        love.graphics.print("You completed the game!!!", Death.font1, (Death.ww / 2) - (textW6 / 2), (Death.wh * 0.40) - (textH6 / 2))
        love.graphics.print("Thank you for playing : )", Death.font2, (Death.ww / 2) - (textW7 / 2), (Death.wh * 0.60) - (textH7 / 2))
        love.graphics.print("\"ENTER\" to skip.", Death.font3, (Death.ww / 2) - (textW4 / 2), (Death.wh * 0.90) - (textH4 / 2))
        love.graphics.print("Score : "..Player.score, Death.font2, (Death.ww / 2) - (textW8 / 2), (Death.wh * 1/5) - (textH8 / 2))
    else
        love.graphics.print(Map.currentWorld.."-"..Map.currentLevel.number, Death.font1, (Death.ww / 2) - (textW2 / 2), (Death.wh * 1/6) - (textH2 / 2))
        love.graphics.print("\"SPACE\" to skip.", Death.font3, (Death.ww / 2) - (textW4 / 2), (Death.wh * 0.90) - (textH4 / 2))
    end

    if Map.currentLevel.number == 1 then
        love.graphics.draw(self.background1, ww / 2 - self.background1:getWidth() / 2, wh / 2 - self.background1:getHeight() / 2)
    elseif Map.currentLevel.number == 2 then
        love.graphics.draw(self.background2, ww / 2 - self.background2:getWidth() / 2, wh / 2 - self.background2:getHeight() / 2)
    elseif Map.currentLevel.number == 3 then
        love.graphics.draw(self.background3, ww / 2 - self.background3:getWidth() / 2, wh / 2 - self.background3:getHeight() / 2)
    end
end

function Transition:skip(key)
    if love.keyboard.isDown("space") and Map.currentLevel.number ~= 4 then
        Menu.alreadyCreated = true
        SCENARIO = "main"
        if Map.currentLevel.number == 2.1 then
            Sound:play("dungeonMusic", "music", 0.3, true)
        elseif Map.currentLevel.number == 3 then
            Sound:play("wind", "music", 0.6, true)
        elseif Map.currentLevel.number == 3.1 then
            Sound:play("mansionMusic", "music", 0.2, true)
        else
            Sound:play("song1", "music", 0.1, true)
        end
    elseif love.keyboard.isDown("return") and Map.currentLevel.number == 4 then
        SCENARIO = "menu"
        Sound:stop("sfx")
        Sound:play("wind", "music", 0.1, true)
        Menu.alreadyCreated = false
        Player.alive = false
        Player.score = 0
        Map:newGameMap()
    end
end

return Transition