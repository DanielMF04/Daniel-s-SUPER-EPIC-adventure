local Sound = require("sound")

local Player = {}

function Player:load()
    self.x = 60
    self.y = 559
    self.startX = self.x
    self.startY = self.y
    self.width = 17
    self.height = 34
    self.xVel = 0
    self.yVel = 0
    self.speed = 200
    self.maxSpeed = 250
    self.acceleration = 3500
    self.friction = 3000 
    self.gravity = 1500
    self.score = 0
    self.health = {current = 3, max = 3, lives = 3}
    self.deathCounter = 0

    self.magicHeartGrabbed = false

    self.jumpAmount = -500
    self.jumpCount = 0
    self.jumpReduce = false
    self.doubleJumpDenie = false

    self.color = {
        red = 1,
        green = 1,
        blue = 1,
        speed = 3,
    }

    self.alive = true
    self.grounded = false

    self.direction = "right"
    self.state = "idle"

    self.physics = {}
    self.physics.body = love.physics.newBody(World, self.x, self.y, "dynamic")
    self.physics.body:setFixedRotation(true)
    self.physics.shape = love.physics.newRectangleShape(self.width, self.height)
    self.physics.fixture = love.physics.newFixture(self.physics.body, self.physics.shape)
    self.physics.body:setGravityScale(0)

    self:loadAssets()
end

function Player:loadAssets()
    self.animation = {timer = 0, rate = 0.1}

    self.animation.run = {total = 4, current = 1, img = {}}
    for i = 1, self.animation.run.total do
        self.animation.run.img[i] = love.graphics.newImage("assets/textures/player/run/"..i..".png")
    end

    self.animation.idle = {total = 5, current = 1, img = {}}
    for i = 1, self.animation.idle.total do
        self.animation.idle.img[i] = love.graphics.newImage("assets/textures/player/idle/"..i..".png")
    end

    self.animation.air = {total = 1, current = 1, img = {}}
    for i = 1, self.animation.air.total do
        self.animation.air.img[i] = love.graphics.newImage("assets/textures/player/air/"..i..".png")
    end

    self.animation.draw = self.animation.idle.img[1]
    self.animation.width = self.width
    self.animation.height = self.height
end

function Player:setNewFrame()
    local anim = self.animation[self.state]
    if anim.current < anim.total then
        anim.current = anim.current + 1
    else
        anim.current = 1
    end
    self.animation.draw = anim.img[anim.current]
end

function Player:animate(dt)
    self.animation.timer = self.animation.timer + dt
    if self.animation.timer > self.animation.rate then
        self.animation.timer = 0
        self:setNewFrame()
    end
end

function Player:setState()
    if self.grounded == false then
        self.state = "air"
    elseif self.xVel == 0 then
        self.state = "idle"
    else
        self.state = "run"
    end
end

function Player:tint(red, green, blue)
    self.color.red = red
    self.color.green = green
    self.color.blue = blue
end

function Player:unTint(dt)
    self.color.red = math.min(self.color.red + self.color.speed * dt, 1)
    self.color.green = math.min(self.color.green + self.color.speed * dt, 1)
    self.color.blue = math.min(self.color.blue + self.color.speed * dt, 1)
end

function Player:takeDamage(amount)
    if self.health.current - amount > 0 then
        Sound:play("hit"..math.random(1, 3).."", "sfx", 0.2)
        self:tint(1, 0, 0)
        self.health.current = self.health.current - amount
        self.yVel = self.jumpAmount * 0.5

        if self.direction == "left" then
            self.xVel = -self.jumpAmount
        elseif self.direction == "right" then
            self.xVel = self.jumpAmount
        end
    else
        self:die()
    end
end

function Player:die()
    SCENARIO = "death"
    self.alive = false
    self.deathCounter = self.deathCounter + 1
    self.health.lives = self.health.lives - 1

    if self.health.lives >= 0 then
        Sound:play("oof", "sfx")
    else
        Sound:play("gameOver", "sfx")
    end
end

function Player:fellFromMap(dt)
    if self.y > 678 then
        self:die()
    end
end

function Player:resetPosition()
    self.physics.body:setPosition(self.startX, self.startY)
end

function Player:updateMaxHealth(amount)
    self.health.max = self.health.max + amount
    self.health.current = self.health.max
end

function Player:updateCurrentHealth(amount)
    if amount + self.health.current <= self.health.max then
        self.health.current = self.health.current + amount
    else
        self.health.current = self.health.max
    end
end

function Player:resetHealth()
    self.health.max = 3
    self.health.current = self.health.max
end

function Player:resetScore()
    self.score = 0
end

function Player:reduceJumping()
    if self.jumpReduce == true then
        self.jumpAmount = -350
        self.jumpCount = 1
    else
        self.jumpAmount = -500
    end
end

function Player:move(dt)
    if true then
        if love.keyboard.isDown("d", "right") then
            self.xVel = math.min(self.xVel + self.acceleration * dt, self.speed)
        end
        if love.keyboard.isDown("a", "left") then
            self.xVel = math.max(self.xVel - self.acceleration * dt, -self.speed)
        end
        if self.xVel == self.speed then
            self.xVel = self.maxSpeed
        end
        if self.xVel == -self.speed then
            self.xVel = -self.maxSpeed
        end
    else
        self:applyFriction(dt)
    end
end

function Player:applyFriction(dt)
    if self.xVel > 0 then
        self.xVel = math.max(self.xVel - self.friction * dt, 0)
    elseif self.xVel < 0 then
        self.xVel = math.min(self.xVel + self.friction * dt, 0)
    end
end

function Player:applyGravity(dt)
    if not self.grounded then
        self.yVel = self.yVel + self.gravity * dt
    end
end

function Player:setDirection()
    if self.xVel < 0 then
        self.direction = "left"
    elseif self.xVel > 0 then
        self.direction = "rigth"
    end
end

function Player:syncPhysics()
    self.x, self.y = self.physics.body:getPosition()
    self.physics.body:setLinearVelocity(self.xVel, self.yVel)
end

function Player:update(dt)
    self:unTint(dt)
    self:setState()
    self:setDirection()
    self:syncPhysics()
    self:move(dt)
    self:applyFriction(dt)
    self:applyGravity(dt)
    self:animate(dt)
    self:fellFromMap(dt)
    self:reduceJumping()
end

function Player:setSpeed(speed, maxSpeed)
    self.speed = speed
    self.maxSpeed = maxSpeed
end

function Player:jump(key)
    if love.keyboard.isDown("w", "up", "space") and self.grounded then
        if self.xVel > 230 then
            self.yVel = self.jumpAmount
        else
            self.yVel = self.jumpAmount * 0.9
        end
        Sound:play("jump", "sfx")
    end
end

function Player:doubleJump(key)
    if self.state == "air" and (key == "w" or key == "up" or key == "space") and self.doubleJumpDenie == false then
        if self.jumpCount == 0 then
            self.yVel = self.jumpAmount * 0.8
            self.jumpCount = self.jumpCount + 1
            Sound:play("doubleJump", "sfx", 0.5)
        end
    end
end

function Player:beginContact(a, b, collision)
    local nx, ny = collision:getNormal()
    if a == self.physics.fixture then
        if ny > 0 then
            self:land(collision)
        elseif ny < 0 then
            self.yVel = 0
        end
    elseif b == self.physics.fixture then
        if ny < 0 then
            self:land(collision)
        elseif ny > 0 then
            self.yVel = 0
        end
    end
end

function Player:endContact(a, b, collision)
    if a == self.physics.fixture or b == self.physics.fixture then
        if self.currentGroundCollision == collision then
            self.grounded = false
        end
    end
end

function Player:land(collision)
    self.yVel = 0
    self.grounded = true
    self.jumpCount = 0
    self.currentGroundCollision = collision
end

function Player:draw()
    local scaleX = 1
    if self.direction == "left" then
        scaleX = -1
    end

    love.graphics.setColor(self.color.red, self.color.green, self.color.blue)
        love.graphics.draw(self.animation.draw, self.x, self.y, 0, scaleX, 1, self.width / 2, self.height / 2)
    love.graphics.setColor(1, 1, 1, 1)
end

return Player