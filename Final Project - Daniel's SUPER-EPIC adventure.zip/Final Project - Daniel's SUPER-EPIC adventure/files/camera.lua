local Player = require("player")
local Map = require("map")

local Camera = {}

function Camera:load()
    self.x = 0
    self.y = 0
    self.scale = 2
    self.xVel = 566
end


function Camera:apply()
    love.graphics.push()
    love.graphics.scale(self.scale, self.scale)
    love.graphics.translate(-self.x, -self.y)
end

function Camera:clear()
    love.graphics.pop()
end

function Camera:update(dt)
    self:setPosition(Player.x, Player.y)
    self:animation(dt)
end

function Camera:setPosition(x, y)
    local offset = 80

    self.x = x - love.graphics.getWidth() / 2 / self.scale
    self.y = y - love.graphics.getHeight() / 2 / self.scale + offset

    local RS = self.x + love.graphics.getWidth() / 2
    local BS = self.y + love.graphics.getHeight() / 2

    if self.y < 0 then
        self.y = 0
    elseif BS > MapHeight then
        self.y = MapHeight - love.graphics.getHeight() / 2
    end

    if self.x < 0 then
        self.x = 0
    elseif RS > MapWidth then
        self.x = MapWidth - love.graphics.getWidth() / 2
    end

    if Map.currentLevel.number == 3 and Player.x > 303 then
        local RS2 = self.x + love.graphics.getWidth()

        self.scale = 1
        self.y = MapHeight - love.graphics.getHeight()
        
        if RS2 > MapWidth then
            self.x = MapWidth - love.graphics.getWidth()
        end
    else
        self.scale = 2
    end

end

function Camera:animation(dt)
    if Map.currentLevel.number == 2.1 and Player.x >= 566 then
        local target = 928
        local acceleration = 100

        self.xVel = math.min(self.xVel + acceleration * dt, target)
        self:setPosition(self.xVel, 152)
    else
        self.xVel = 566
    end

    if Map.currentLevel.number == 3.1 and Player.y < 255 then
        self.y = 255 - love.graphics.getHeight() / 2 + 100
    end
end

    return Camera