local Player = require("player")
local Sound = require("sound")
local GUI = require("gui")

local MagicHeart = {}
MagicHeart.__index = MagicHeart
local ActiveMagicHearts = {}

function MagicHeart.new(x,y)
    local instance = setmetatable({}, MagicHeart)
    instance.x = x
    instance.y = y

    instance.img = love.graphics.newImage("assets/textures/entities/magic_heart.png")
    instance.width = instance.img:getWidth()
    instance.height = instance.img:getHeight()

    instance.toBeRemoved = false

    instance.physics = {}
    instance.physics.body = love.physics.newBody(World, instance.x, instance.y, "static")
    instance.physics.shape = love.physics.newRectangleShape(instance.width, instance.height)
    instance.physics.fixture = love.physics.newFixture(instance.physics.body, instance.physics.shape)
    instance.physics.fixture:setSensor(true)

    table.insert(ActiveMagicHearts, instance)
end

function MagicHeart:float()
    self.y = self.y + math.sin(love.timer.getTime() * 4) * 0.05
end

function MagicHeart.beginContact(a, b, collision)
    for i,instance in ipairs(ActiveMagicHearts) do
        if a == instance.physics.fixture or b == instance.physics.fixture then
            if a == Player.physics.fixture or b == Player.physics.fixture then
                instance.toBeRemoved = true
                return true
            end
        end
    end
end

function MagicHeart:remove()
    for i, instance in ipairs(ActiveMagicHearts) do
        if instance == self then
            Player:tint(1, 1, 0)
            GUI:heartsTint(1, 1, 0)
            Player:updateMaxHealth(1)
            GUI:updateScore(1000)
            Sound:play("magicHeart", "sfx", 0.5)
            self.physics.body:destroy()
            table.remove(ActiveMagicHearts, i)
            Player.magicHeartGrabbed = true
        end
    end
end

function MagicHeart:checkRemoved()
    if self.toBeRemoved then
        self:remove()
    end
end

function MagicHeart:removeAll()
    for i,v in ipairs(ActiveMagicHearts) do
        v.physics.body:destroy()
    end

    ActiveMagicHearts = {}
end

function MagicHeart:update(dt)
    self:checkRemoved()
    self:float()

    if Player.health.lives < 0 then
        Player.magicHeartGrabbed = false
    end
end

function MagicHeart.updateAll(dt)
    if Player.magicHeartGrabbed == false then
        for i,instance in ipairs(ActiveMagicHearts) do
            instance:update(dt)
        end
    end
end

function MagicHeart:draw()
    love.graphics.setColor(0, 0, 0, 0.25)
        love.graphics.draw(self.img, self.x + 1.5, self.y + 1.5, 0, 1, 1, self.width / 2, self.height / 2)
    love.graphics.setColor(1, 1, 1, 1)
        love.graphics.draw(self.img, self.x, self.y, 0, 1, 1, self.width / 2, self.height / 2)
end

function MagicHeart.drawAll()
    if Player.magicHeartGrabbed == false then
        for i,instance in ipairs(ActiveMagicHearts) do
            instance:draw()
        end
    end
end

return MagicHeart