local Player = require("player")
local GUI = require("gui")

local Blue_slime = {}
Blue_slime.__index = Blue_slime
local ActiveBlue_slimes = {}

function Blue_slime.new(x,y)
    local instance = setmetatable({}, Blue_slime)
    instance.x = x
    instance.y = y

    instance.speed = 100
    instance.speedMod = 2
    instance.xVel = instance.speed

    instance.rageCounter = 0
    instance.rageTrigger = 2

    instance.damage = 1

    instance.state = "walk"

    instance.animation = {timer = 0, rate = 0.1}
    instance.animation.run = {total = 4, current = 1, img = Blue_slime.runAnim}
    instance.animation.walk = {total = 4, current = 1, img = Blue_slime.walkAnim}
    instance.animation.draw = instance.animation.walk.img[1]

    instance.physics = {}
    instance.physics.body = love.physics.newBody(World, instance.x, instance.y, "dynamic")
    instance.physics.body:setFixedRotation(true)
    instance.physics.shape = love.physics.newRectangleShape(instance.width * 0.4, instance.height * 0.75)
    instance.physics.fixture = love.physics.newFixture(instance.physics.body, instance.physics.shape)

    table.insert(ActiveBlue_slimes, instance)
end

function Blue_slime.loadAssets()
    Blue_slime.runAnim = {}
    for i = 1, 4 do
        Blue_slime.runAnim[i] = love.graphics.newImage("assets/textures/entities/blue_slime/run/"..i..".png")
    end

    Blue_slime.walkAnim = {}
    for i = 1, 4 do
        Blue_slime.walkAnim[i] = love.graphics.newImage("assets/textures/entities/blue_slime/walk/"..i..".png")
    end

    Blue_slime.width = Blue_slime.runAnim[1]:getWidth()
    Blue_slime.height = Blue_slime.runAnim[1]:getHeight()
end

function Blue_slime:setNewFrame()
    local anim = self.animation[self.state]
    if anim.current < anim.total then
        anim.current = anim.current + 1
    else
        anim.current = 1
    end
    self.animation.draw = anim.img[anim.current]
end

function Blue_slime:animate(dt)
    self.animation.timer = self.animation.timer + dt
    if self.animation.timer > self.animation.rate then
        self.animation.timer = 0
        self:setNewFrame()
    end
end

function Blue_slime.beginContact(a, b, collision)
    for i,instance in ipairs(ActiveBlue_slimes) do
        if a == instance.physics.fixture or b == instance.physics.fixture then
            if a == Player.physics.fixture or b == Player.physics.fixture then
                GUI:updateScore(-100)
                Player:takeDamage(instance.damage)
            end
            instance:flipDirection()
            instance:incrementRage()
        end
    end
end

function Blue_slime:removeAll()
    for i,v in ipairs(ActiveBlue_slimes) do
        v.physics.body:destroy()
    end

    ActiveBlue_slimes = {}
end

function Blue_slime:update(dt)
    self:syncPhysics()
    self:animate(dt)
end

function Blue_slime.updateAll(dt)
    for i,instance in ipairs(ActiveBlue_slimes) do
        instance:update(dt)
    end
end

function Blue_slime:incrementRage()
    self.rageCounter = self.rageCounter + 1
    if self.rageCounter > self.rageTrigger then
        self.state = "run"
        self.speedMod = 3
        self.rageCounter = 0
    else
        self.state = "walk"
        self.speedMod = 1
    end
end

function Blue_slime:flipDirection()
    self.xVel = -self.xVel
end

function Blue_slime:syncPhysics()
    self.x, self.y = self.physics.body:getPosition()
    self.physics.body:setLinearVelocity(self.xVel * self.speedMod, 100)
end

function Blue_slime:draw()
    local scaleX = -1
    if self.xVel < 0 then
        scaleX = 1
    end

    love.graphics.draw(self.animation.draw, self.x, self.y - 1.5, 0, scaleX, 1, self.width / 2, self.height / 2)
end

function Blue_slime.drawAll()
    for i,instance in ipairs(ActiveBlue_slimes) do
        instance:draw()
    end
end

return Blue_slime