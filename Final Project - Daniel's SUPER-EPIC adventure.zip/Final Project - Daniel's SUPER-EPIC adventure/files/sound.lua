
local Sound = {active = {}, source = {}}

function Sound:init(id, source, soundType)
    assert(self.source[id] == nil, "ID Error")
    self.source[id] = love.audio.newSource(source, soundType)
end

function Sound:load()
    Sound:init("coin", "assets/sounds/sfx/coin_pickup.ogg", "static")
    Sound:init("hit1", "assets/sounds/sfx/hit1.ogg", "static")
    Sound:init("hit2", "assets/sounds/sfx/hit2.ogg", "static")
    Sound:init("hit3", "assets/sounds/sfx/hit3.ogg", "static")
    Sound:init("jump", "assets/sounds/sfx/jump.ogg", "static")
    Sound:init("doubleJump", "assets/sounds/sfx/doubleJump.wav", "static")
    Sound:init("magicHeart", "assets/sounds/sfx/magic_heart_pickup.x-wav", "static")
    Sound:init("heart", "assets/sounds/sfx/heart_pickup.x-wav", "static")
    Sound:init("crate", "assets/sounds/sfx/crate.wav", "static")
    Sound:init("dungeonMusic", "assets/sounds/music/dungeon_music.mp3", "static")
    Sound:init("changingMap", "assets/sounds/sfx/changing_map.mp3", "static")
    Sound:init("usingDoor", "assets/sounds/sfx/using_door.mp3", "static")
    Sound:init("oof", "assets/sounds/sfx/oof.mp3", "static")
    Sound:init("button1", "assets/sounds/sfx/button1.wav", "static")
    Sound:init("wind", "assets/sounds/music/wind.wav", "static")
    Sound:init("song1", "assets/sounds/music/song1.mp3", "static")
    Sound:init("gameOver", "assets/sounds/sfx/game_over.mp3", "static")
    Sound:init("mansionMusic", "assets/sounds/music/mansion_music.mp3", "static")
    Sound:init("victory", "assets/sounds/sfx/victory.mp3", "static")
end

function Sound:play(id, channel, volume, loop)
    local channel = channel or "default"
    local clone = Sound.source[id]:clone()
    clone:setVolume(volume or 1)
    clone:setLooping(loop or false)
    clone:play()

    if Sound.active[channel] == nil then
        Sound.active[channel] = {}
    end
    table.insert(Sound.active[channel], clone)
end

function Sound:setVolume(channel, volume)
    for k, sound in ipairs(Sound.active[channel]) do
        sound:setVolume(volume)
    end
end

function Sound:stop(channel)
    for k, sound in ipairs(Sound.active[channel]) do
        sound:stop()
    end
end

function Sound:update(dt)
    for k, channel in pairs(Sound.active) do
        if channel[1] ~= nil and not channel[1]:isPlaying() then
            table.remove(channel, 1)
        end
    end
end

return Sound
