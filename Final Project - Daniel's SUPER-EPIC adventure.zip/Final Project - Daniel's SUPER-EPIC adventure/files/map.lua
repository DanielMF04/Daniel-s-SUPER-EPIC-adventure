local Player = require("player")
local Blue_slime = require("Blue_slime")
local Purple_slime = require("purple_slime")
local Coin = require("coin")
local Crate = require("crate")
local Spike = require("spike")
local MagicHeart = require("magicHeart")
local Heart = require("heart")
local STI = require("sti")
local GUI = require("gui")
local Door = require("door")
local Sound = require("sound")

local Map = {}

function Map:load()
    self.dayBackground = love.graphics.newImage("assets/textures/backgrounds/background.png")
    self.nightBackground = love.graphics.newImage("assets/textures/backgrounds/night_background.jpg")
    self.sunsetBackground = love.graphics.newImage("assets/textures/backgrounds/sunset_background.jpg")

    self.currentWorld = 1
    self.currentLevel = {
        number = 1,
        x = 60,
        y = 559
    }
    World = love.physics.newWorld(0,2000)
    World:setCallbacks(beginContact, endContact)

    self.inRoom = false
    self.gameOver = false

    self:init()
end

function Map:init()
    self.level = STI("map/"..self.currentLevel.number..".lua", {"box2d"})
    self.level:box2d_init(World)

    self.level.layers.solid.visible = false
    self.level.layers.entity.visible = false

    MapWidth = self.level.layers.ground.width * 16
    MapHeight = self.level.layers.ground.height * 16

    self:spawnEntities()
end

function Map:spawnEntities()
    for i,v in ipairs(self.level.layers.entity.objects) do
        if v.class == "spikes" then
            Spike.new(v.x + v.width / 2, v.y + v.height / 2)
        elseif v.class == "crate" then
            Crate.new(v.x + v.width / 2, v.y + v.height / 2)
        elseif v.class == "blue_slime" then
            Blue_slime.new(v.x + v.width / 2, v.y + v.height / 2)
        elseif v.class == "purple_slime" then
            Purple_slime.new(v.x + v.width / 2, v.y + v.height / 2)
        elseif v.class == "coin" then
            Coin.new(v.x, v.y)
        elseif v.class == "magic_heart" then
            MagicHeart.new(v.x + v.width / 2, v.y + v.height / 2)
        elseif v.class == "heart" then
            Heart.new(v.x + v.width / 2, v.y + v.height / 2)
        elseif v.class == "door" then
            Door.new(v.x + v.width / 2, v.y + v.height / 2, v.width, v.height)
        end
    end
end

function Map:levelCoordinates()
    if self.currentLevel.number == 1 then
        self:setCoordinates(60, 559)
    elseif self.currentLevel.number == 2 then
        self:setCoordinates(10, 176)
    elseif self.currentLevel.number == 2.1 then
        self:setCoordinates(80, 256)
    elseif self.currentLevel.number == 3 then
        self:setCoordinates(17, 462)
    elseif self.currentLevel.number == 3.1 then
        self:setCoordinates(1119, 542)
    end
end

function Map:setCoordinates(x, y)
    self.currentLevel.x = x
    self.currentLevel.y = y
end

function Map:levelShadowsAndSpeed()
    if self.currentLevel.number == 2.1 then
        local inDimShadow = Player.x < 31 or Player.x > 128 and Player.x < 845 or 
        Player.x > 1015 or Player.x > 31 and Player.x < 128 and Player.y < 215
        local inDarkShadow = Player.x > 175 and Player.x < 816 or Player.x > 1040

        Player.doubleJumpDenie = true
        Player:setSpeed(120, 170)

        if inDimShadow then
            Player:tint(0.5, 0.5, 0.5)
            if inDarkShadow then
                Player:tint(0.25, 0.25, 0.25)
            end
        else
            Player:tint(1, 1, 1)
        end
    else
        Player:setSpeed(200, 250)
        Player.doubleJumpDenie = false
    end

    if self.currentLevel.number == 3 then
        Player:tint(0.5, 0.5, 0.5)
    end
end

function Map:updateLevel()
    self:levelCoordinates()
    self:levelShadowsAndSpeed()
end

function Map:resetPosition()
    Player.physics.body:setPosition(self.currentLevel.x, self.currentLevel.y)
end

function Map:clean()
    Coin.removeAll()
    MagicHeart.removeAll()
    Heart.removeAll()
    Blue_slime.removeAll()
    Purple_slime.removeAll()
    Crate.removeAll()
    Spike.removeAll()
    Door.removeAll()
end

function Map:nextMap()
    self:clean()
    self.level:box2d_removeLayer("solid")
    self.currentLevel.number = self.currentLevel.number + 1
    self:init()
    self:updateLevel()
    self:resetPosition()
end

function Map:setMap(i)
    self:clean()
    self.level:box2d_removeLayer("solid")
    self.currentLevel.number = i
    self:init()
    self:updateLevel()
    self:resetPosition()
end

function Map:playerCompletedLevel(dt)
    if Player.x > MapWidth then
        if self.currentLevel.number ~= 3 then
            self:nextMap()
            GUI:resetTimer()
            Sound:play("changingMap", "sfx")
            SCENARIO = "transition"
            Sound:stop("music")
        else
            self.currentLevel.number = 4
            SCENARIO = "transition"
            Sound:play("victory", "sfx", 0.2)
            Sound:stop("music")
        end
    end
end

function Map:cleanAndSpawnEntities(dt)
    if Player.alive == false then
        self:clean()
        self:spawnEntities()
    end
end

function Map:respawn()
    if Player.alive == false then
        self:resetPosition()
        GUI:resetTimer()
        Player.health.current = Player.health.max
        Player.alive = true
    end
end

function Map:update(dt)
    self:updateLevel()
    self:playerCompletedLevel(dt)
    self:cleanAndSpawnEntities(dt)
    self:respawn()
end

function Map:newGameMap()
    self:clean()
    self.level:box2d_removeLayer("solid")
    self.currentLevel.number = 1
    self:init()
    self:updateLevel()
    self:resetPosition()
    Player.health.lives = 3
    Player.magicHeartGrabbed = false
end

function Map:enterDoor(key)
    Sound:stop("music")
    Sound:play("usingDoor","sfx")
    SCENARIO = "transition"

    if self.inRoom == false then
        if Map.currentLevel.number == 2 then
            self:setMap(2.1)
        elseif Map.currentLevel.number == 3 then
            self:setMap(3.1)
        end
    elseif self.inRoom == true then
        if Map.currentLevel.number == 2.1 then
            self:setMap(2)
            Player.physics.body:setPosition(1758, 559)
            Coin.removeAll()
            Heart.removeAll()
        elseif Map.currentLevel.number == 3.1 then
            self:setMap(3)
            Player.physics.body:setPosition(1857, 382)
        end
    end
end

function Map:draw()
    if self.currentLevel.number == 3 then
        love.graphics.draw(self.nightBackground)
    elseif self.currentLevel.number == 2 then
        love.graphics.draw(self.sunsetBackground)
    else
        love.graphics.draw(self.dayBackground)
    end
end

return Map